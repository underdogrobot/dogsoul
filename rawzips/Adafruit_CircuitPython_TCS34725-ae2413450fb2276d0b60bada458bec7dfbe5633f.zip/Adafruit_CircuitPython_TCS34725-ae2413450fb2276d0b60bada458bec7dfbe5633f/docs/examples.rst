Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/tcs34725_simpletest.py
    :caption: examples/tcs34725_simpletest.py
    :linenos:
