Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/ws2801_simpletest.py
    :caption: examples/ws2801_simpletest.py
    :linenos:
